import fs from "node:fs/promises";
import path from "node:path";
import { Presentation, PresentationFile } from "@oai/artifact-tool";

const ROOT = "/workspace/scratch/97924070f13d";
const SOURCE = path.join(
  ROOT,
  "sourcepack",
  "DAILYCOACHING_미술심리코칭_6주_PPT_WORK_SOURCEPACK_v1.0",
);
const OUT = path.join(ROOT, "FINAL_OUTPUT");
const TMP = path.join(ROOT, "build_tmp");
const MANIFEST = path.join(SOURCE, "03_DATA", "SLIDE_MANIFEST_114.csv");

const C = {
  navy: "#101828",
  navy2: "#1D2939",
  warm: "#F6F1E7",
  paper: "#FFFDF8",
  yellow: "#F4CE46",
  orange: "#D16D4F",
  teal: "#4E8B83",
  blue: "#A8C2D1",
  gray: "#667085",
  line: "#D8D0C4",
  white: "#FFFDF8",
};

const WEEK = {
  W01: { accent: C.blue, title: "지금의 나를 바라보는 자리" },
  W02: { accent: C.orange, title: "내면아이와 지금의 내가 만나는 자리" },
  W03: { accent: C.teal, title: "지금의 나를 새롭게 그려보기" },
  W04: { accent: C.yellow, title: "미래의 한 장면을 먼저 그려보기" },
  W05: { accent: C.orange, title: "바라는 장면을 행동으로 옮기기" },
  W06: { accent: C.navy, title: "나를 다시 세우는 자기강화와 통합" },
};

const WEEK_FILES = {
  W01: "WEEK01_나를_바라보는_자리_v1.0.pptx",
  W02: "WEEK02_내면아이와의_만남_v1.0.pptx",
  W03: "WEEK03_지금의_나를_새롭게_그리기_v1.0.pptx",
  W04: "WEEK04_미래의_한_장면_v1.0.pptx",
  W05: "WEEK05_행동으로_번역하기_v1.0.pptx",
  W06: "WEEK06_자기강화와_통합_v1.0.pptx",
};

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') {
        quoted = false;
      } else {
        field += ch;
      }
    } else if (ch === '"') {
      quoted = true;
    } else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      field = "";
    } else {
      field += ch;
    }
  }
  if (field.length || row.length) {
    row.push(field);
    rows.push(row);
  }
  const headers = rows.shift().map((v) => v.replace(/^\uFEFF/, ""));
  return rows
    .filter((r) => r.some((v) => v !== ""))
    .map((r) => Object.fromEntries(headers.map((h, i) => [h, r[i] ?? ""])));
}

function addShape(slide, geometry, name, position, fill = "none", line = undefined) {
  return slide.shapes.add({ geometry, name, position, fill, line });
}

function addText(slide, name, text, position, style = {}) {
  const shape = addShape(slide, "textbox", name, position, "none", {
    style: "solid",
    fill: "none",
    width: 0,
  });
  shape.text = text;
  shape.text.style = {
    typeface: "Noto Sans KR",
    fontSize: 40,
    color: C.navy,
    bold: false,
    lineSpacing: 1.04,
    alignment: "left",
    verticalAlignment: "top",
    autoFit: "shrinkText",
    wrap: "square",
    insets: { top: 0, right: 0, bottom: 0, left: 0 },
    ...style,
  };
  return shape;
}

function rule(slide, name, left, top, width, color, height = 2) {
  return addShape(
    slide,
    "rect",
    name,
    { left, top, width, height },
    color,
    { style: "solid", fill: color, width: 0 },
  );
}

function circle(slide, name, left, top, size, lineColor, fill = "none", width = 3) {
  return addShape(
    slide,
    "ellipse",
    name,
    { left, top, width: size, height: size },
    fill,
    { style: "solid", fill: lineColor, width },
  );
}

function baseChrome(slide, row, dark = false) {
  const ink = dark ? C.white : C.navy;
  const muted = dark ? "#B8C0CC" : C.gray;
  addText(
    slide,
    `${row.slide_id}-week`,
    `${row.week}  /  ${String(row.slide_no).padStart(2, "0")}`,
    { left: 92, top: 62, width: 420, height: 30 },
    { fontSize: 21, bold: true, color: muted },
  );
  addText(
    slide,
    `${row.slide_id}-label`,
    row.screen_title,
    { left: 92, top: 104, width: 820, height: 46 },
    { fontSize: 24, bold: true, color: ink },
  );
  addText(
    slide,
    `${row.slide_id}-brand`,
    "DAILYCOACHING",
    { left: 92, top: 1015, width: 310, height: 24 },
    { fontSize: 17, bold: true, color: muted },
  );
  addText(
    slide,
    `${row.slide_id}-id`,
    row.slide_id,
    { left: 1640, top: 1015, width: 190, height: 24 },
    { fontSize: 17, bold: true, color: muted, alignment: "right" },
  );
}

function bodyFont(text, max = 82) {
  const n = [...text].length;
  if (n <= 24) return max;
  if (n <= 38) return Math.min(max, 74);
  if (n <= 58) return Math.min(max, 66);
  if (n <= 82) return Math.min(max, 57);
  return Math.min(max, 50);
}

function spokenInvitation(row, meta) {
  const body = row.screen_body;
  switch (row.phase) {
    case "타이틀":
      return `“${body}.” 오늘은 ‘${meta.coreQuestion}’라는 질문을 따라가겠습니다. 정답을 만들기보다 지금 보이는 만큼만 함께 살펴보겠습니다.`;
    case "진입":
      return `“${body}” 이 문장을 천천히 읽겠습니다. 설명을 바로 붙이지 않고, 지금 떠오르는 느낌이 자리 잡도록 잠시 기다리겠습니다.`;
    case "체크인":
      return `“${body}” 길게 설명하지 않아도 됩니다. 감정이나 몸의 느낌 가운데 지금 가장 가까운 단어 하나만 적어보세요.`;
    case "안전":
      return `“${body}” 이것은 안내 문구가 아니라 실제 선택권입니다. 어떤 질문도 건너뛸 수 있고, 언제든 멈추거나 자리를 옮길 수 있습니다.`;
    case "연결":
      return `“${body}” 했는지 못했는지를 평가하지 않겠습니다. 그 사이에 알아차린 작은 변화나 반복 하나만 골라 이야기해 주세요.`;
    case "스토리":
      return `지금부터 짧은 장면을 읽겠습니다. 눈을 감을 필요는 없습니다. “${body}” 떠오르는 만큼만 머물러 보겠습니다.`;
    case "공개":
      return `오늘의 활동은 “${body.replace(/^ACTIVITY\s*\/\s*/, "")}”입니다. 완성 예시를 따라 그리지 않고, 자신의 방식으로 시작합니다.`;
    case "준비":
      return `“${body}” 스케치북은 그림을 위한 자리, 워크북은 말과 발견을 남기는 자리입니다. 준비되면 고개만 들어 주세요.`;
    case "안내":
      return `“${body}” 여기에 나온 요소를 모두 넣을 필요는 없습니다. 글자, 기호, 색면, 선, 비어 있는 자리만 사용해도 좋습니다.`;
    case "허용":
      return `“${body}” 이 한 문장만 기억하고 각자의 속도로 시작하겠습니다. 잘 그렸는지는 오늘의 기준이 아닙니다.`;
    case "작업":
      return `“${body}” 지금부터 25분입니다. 처음 5분과 마지막 5분에만 시간을 안내하겠습니다. 질문이 있으면 손을 들어 주세요.`;
    case "관찰":
      return `“${body}” 바로 의미를 정하지 말고, 먼저 실제로 보이는 것과 지금 느껴지는 것을 구분해 천천히 살펴보겠습니다.`;
    case "발화":
      return `“${body}” 완벽한 문장일 필요는 없습니다. 그림 속 존재가 지금 말하는 것처럼 1인칭 한 문장으로 들려주세요.`;
    case "심화":
      return `“${body}” 제가 의미를 정하지 않겠습니다. 당신이 고른 단어를 중심으로, 지켜준 점과 지금 필요한 점을 함께 보겠습니다.`;
    case "나눔":
      return `“${body}” 듣는 사람은 조언하거나 해석하지 않습니다. ‘제가 들은 핵심은…’으로 한 번만 반영해 주세요.`;
    case "통합":
      return `“${body}” 모두가 말할 필요는 없습니다. 나누고 싶은 분의 문장 두세 개만 받고, 서로 다른 표현을 그대로 두겠습니다.`;
    case "적용":
      return `“${body}” 크게 바꾸기보다 실제 생활에서 확인할 수 있는 가장 작은 행동과 다시 시작하는 방법을 정하겠습니다.`;
    case "종결":
      return `“${body}” 빈칸은 자신의 단어로 완성합니다. 원한다면 직접 읽고, 읽지 않고 기록만 남겨도 괜찮습니다.`;
    default:
      return `“${body}” 화면의 문장을 천천히 읽고, 각자의 선택과 속도를 존중하며 진행하겠습니다.`;
  }
}

function nextQuestion(row) {
  switch (row.phase) {
    case "타이틀": return "이 질문을 들었을 때 지금 가장 먼저 떠오르는 단어는 무엇인가요?";
    case "진입": return "이 장면과 지금의 나 사이에 어떤 느낌이 있나요?";
    case "체크인": return "그 단어는 몸의 어느 부분에서 가장 가까이 느껴지나요?";
    case "안전": return "오늘 자신에게 필요한 참여 방식은 무엇인가요?";
    case "연결": return "그 경험에서 새롭게 알아차린 것은 무엇인가요?";
    case "스토리": return "이 장면에서 가장 먼저 눈에 들어오는 것은 무엇인가요?";
    case "공개": return "이 활동을 어떤 거리와 방식으로 시작하고 싶나요?";
    case "준비": return "그림과 기록 가운데 어느 것부터 시작하면 편안한가요?";
    case "안내": return "여러 요소 중 지금 넣고 싶은 것 하나는 무엇인가요?";
    case "허용": return "지금 가능한 만큼은 어느 정도인가요?";
    case "작업": return "지금 더 필요한 것은 시간, 거리, 재료, 휴식 중 무엇인가요?";
    case "관찰": return "설명하지 않고 보이는 사실만 말하면 무엇이 있나요?";
    case "발화": return "그 문장을 ‘나는…’으로 시작하면 어떻게 들리나요?";
    case "심화": return "그 방식이 지켜준 것과 지금 치르는 대가는 각각 무엇인가요?";
    case "나눔": return "상대의 말에서 그대로 되돌려 주고 싶은 핵심 단어는 무엇인가요?";
    case "통합": return "오늘의 여러 문장 사이에서 공통으로 남는 것은 무엇인가요?";
    case "적용": return "이 행동을 가장 작게 시작한다면 언제 무엇을 하면 될까요?";
    case "종결": return "이 문장을 오늘의 나에게 어떤 목소리로 들려주고 싶나요?";
    default: return "지금 이 장면에서 더 살펴보고 싶은 것은 무엇인가요?";
  }
}

function alternativeQuestion(row) {
  switch (row.phase) {
    case "타이틀":
    case "진입": return "말 대신 색 하나, 선 하나, 또는 몸의 느낌 하나로 골라도 괜찮습니다.";
    case "체크인": return "정확한 감정명이 어렵다면 ‘편안함/불편함/잘 모르겠음’ 중 하나를 골라도 됩니다.";
    case "안전": return "지금은 ‘계속하기/건너뛰기/잠시 쉬기’ 중 무엇이 가장 필요한가요?";
    case "연결": return "특별한 변화가 없었다면 ‘그대로였던 것’ 하나를 말해도 됩니다.";
    case "스토리": return "장면이 떠오르지 않으면 날씨나 색 하나만 골라도 됩니다.";
    case "공개":
    case "안내": return "사람이나 사물을 그리지 않고 선, 색, 거리만으로 표현한다면 무엇부터 시작할까요?";
    case "준비": return "지금 손에 먼저 잡고 싶은 재료 하나만 골라볼까요?";
    case "허용": return "완성하지 않아도 괜찮다면 첫 표시를 어디에 남기고 싶나요?";
    case "작업": return "지금은 그리지 않고 잠시 바라보거나 한 단어만 적어도 괜찮습니다.";
    case "관찰": return "무엇이 보이는지 말하기 어렵다면 가장 진한 곳, 빈 곳, 시선이 머무는 곳 중 하나를 골라보세요.";
    case "발화": return "문장 대신 한 단어, 소리, 또는 말하지 않기를 선택해도 됩니다.";
    case "심화": return "욕구가 어렵다면 ‘더 가까이/더 멀리/그대로’ 중 어디에 가까운가요?";
    case "나눔": return "설명 대신 작품에서 소개하고 싶은 부분 하나만 가리켜도 됩니다.";
    case "통합": return "전체 이야기가 어렵다면 오늘 남기고 싶은 단어 하나만 골라도 됩니다.";
    case "적용": return "행동 대신 ‘멈출 것 하나’ 또는 ‘도움을 요청할 사람 하나’를 정해도 됩니다.";
    case "종결": return "빈칸을 채우지 않고 지금 남은 느낌만 표시해도 괜찮습니다.";
    default: return "어느 부분부터 소개하고 싶은지 하나만 골라도 됩니다.";
  }
}

function transitionText(row, nextRow) {
  if (!nextRow || nextRow.week !== row.week) {
    return "오늘의 문장을 자신의 기록으로 남기고, 서두르지 않고 회기를 마치겠습니다.";
  }
  const map = {
    "타이틀": "이제 설명보다 현재의 감각으로 들어가 보겠습니다.",
    "진입": "먼저 지금 이 자리에 도착한 몸과 감정을 확인하겠습니다.",
    "체크인": "깊이 들어가기 전에 오늘의 선택권을 다시 확인하겠습니다.",
    "안전": "선택권을 가진 채 지난 시간과 오늘을 연결해 보겠습니다.",
    "연결": "이제 말로만 설명하지 않고 하나의 장면으로 들어가 보겠습니다.",
    "스토리": "장면이 열렸다면 오늘의 그림 활동을 공개하겠습니다.",
    "공개": "시작하기 전에 필요한 재료와 기록 자리를 확인하겠습니다.",
    "준비": "재료가 준비되면 표현 방법의 선택지를 짧게 안내하겠습니다.",
    "안내": "이제 잘해야 한다는 부담을 내려놓는 한 문장을 기억하겠습니다.",
    "허용": "각자의 속도로 그림 활동을 시작하겠습니다.",
    "작업": "손을 멈춘 뒤, 수정하기 전에 먼저 작품을 바라보겠습니다.",
    "관찰": nextRow.phase === "관찰"
      ? "이제 보이는 사실을 붙잡는 질문 하나로 시선을 좁혀보겠습니다."
      : "보이는 것을 확인했으니 그림 속 목소리를 한 문장으로 들어보겠습니다.",
    "발화": "그 목소리가 지켜온 것과 지금 필요한 것을 함께 살펴보겠습니다.",
    "심화": "정답을 만들지 않고, 들은 핵심을 소그룹에서 반영해 보겠습니다.",
    "나눔": "소그룹에서 나온 문장 가운데 전체와 나누고 싶은 것을 선택하겠습니다.",
    "통합": "오늘의 발견을 생활에서 확인할 수 있는 작은 행동으로 옮기겠습니다.",
    "적용": "마지막으로 자신의 언어로 회기를 닫는 문장을 완성하겠습니다.",
    "종결": "기록을 정리하고 현재의 감각을 확인한 뒤 마치겠습니다.",
  };
  return map[row.phase] ?? `다음 화면 ‘${nextRow.screen_title}’로 이동하겠습니다.`;
}

function buildNotes(row, nextRow, meta) {
  return [
    `SLIDE_ID: ${row.slide_id}`,
    `목적: ${row.facilitator_purpose}`,
    `권장 시간: ${row.time_min}분`,
    `진행자 실제 발화: ${spokenInvitation(row, meta)}`,
    `다음 질문: ${nextQuestion(row)}`,
    `참여자가 막혔을 때의 대체 질문: ${alternativeQuestion(row)}`,
    `정서 반응이 커졌을 때의 대응: ${row.safety_note} 질문과 해석을 멈추고 현재 장소와 시간을 확인한다. 발바닥·의자·주변의 색을 느끼게 한 뒤, 물 마시기·자리 이동·잠시 쉬기 중에서 참여자가 선택하게 한다. 계속 참여할지 스스로 고르게 하고, 구체적 위험 표현이 있으면 합의된 전문 지원 절차로 연결한다.`,
    `워크북 코드: ${row.workbook_id}`,
    `다음 슬라이드 전환 문장: ${transitionText(row, nextRow)}`,
    "",
    "[Sources]",
    `- 사용자 제공 소스팩: SLIDE_MANIFEST_114.csv / ${row.week} 주차 대본`,
  ].join("\n");
}

function readWeekMeta(script) {
  const get = (label) => {
    const m = script.match(new RegExp(`\\*\\*${label}:\\*\\*\\s*([^\\n]+)`));
    return m ? m[1].trim() : "";
  };
  return {
    scene: get("장면"),
    coreQuestion: get("핵심 질문"),
    activity: get("활동"),
  };
}

function drawTitle(slide, row, accent) {
  slide.background.fill = C.warm;
  baseChrome(slide, row, false);
  addText(slide, `${row.slide_id}-giant-week`, row.week, { left: 82, top: 155, width: 720, height: 250 }, {
    fontSize: 220, bold: true, color: accent,
  });
  rule(slide, `${row.slide_id}-title-rule`, 96, 470, 1720, C.navy, 4);
  const title = row.screen_body;
  addText(slide, `${row.slide_id}-body`, title, { left: 92, top: 535, width: 1510, height: 260 }, {
    fontSize: bodyFont(title, 104), bold: true, color: C.navy, lineSpacing: 0.94,
  });
  addText(slide, `${row.slide_id}-prompt`, "ARRIVE  ·  DRAW  ·  READ  ·  CONNECT", { left: 96, top: 850, width: 1150, height: 50 }, {
    fontSize: 26, bold: true, color: C.gray,
  });
  circle(slide, `${row.slide_id}-circle`, 1610, 760, 150, C.navy, "none", 3);
  rule(slide, `${row.slide_id}-circle-line`, 1685, 745, 3, C.navy, 180);
}

function drawScene(slide, row, accent) {
  slide.background.fill = C.paper;
  baseChrome(slide, row, false);
  addText(slide, `${row.slide_id}-backword`, "SCENE", { left: 840, top: 155, width: 970, height: 190 }, {
    fontSize: 170, bold: true, color: `${accent}/25`, alignment: "right",
  });
  rule(slide, `${row.slide_id}-accent`, 94, 210, 22, accent, 610);
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 170, top: 270, width: 1420, height: 410 }, {
    fontSize: bodyFont(row.screen_body, 90), bold: true, color: C.navy, lineSpacing: 1.0,
  });
  addText(slide, `${row.slide_id}-pause`, "잠시 머물러 봅니다.", { left: 170, top: 760, width: 720, height: 50 }, {
    fontSize: 28, color: C.gray,
  });
}

function drawQuestion(slide, row, accent, quote = false) {
  slide.background.fill = C.warm;
  baseChrome(slide, row, false);
  addText(slide, `${row.slide_id}-q`, quote ? "“" : "Q.", { left: 86, top: 170, width: 350, height: 260 }, {
    fontSize: quote ? 230 : 190, bold: true, color: accent,
  });
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 390, top: 250, width: 1390, height: 450 }, {
    fontSize: bodyFont(row.screen_body, 86), bold: true, color: C.navy, lineSpacing: 1.02,
  });
  rule(slide, `${row.slide_id}-under`, 390, 790, 760, accent, 8);
  addText(slide, `${row.slide_id}-cue`, quote ? "한 문장으로 들려주세요." : "보이는 것부터, 자신의 언어로.", { left: 390, top: 830, width: 900, height: 50 }, {
    fontSize: 27, color: C.gray,
  });
}

function drawSafety(slide, row, accent) {
  slide.background.fill = C.navy;
  baseChrome(slide, row, true);
  addText(slide, `${row.slide_id}-choice`, "CHOICE", { left: 90, top: 160, width: 1000, height: 200 }, {
    fontSize: 160, bold: true, color: `${accent}/35`,
  });
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 96, top: 390, width: 1640, height: 260 }, {
    fontSize: bodyFont(row.screen_body, 82), bold: true, color: C.white, lineSpacing: 1.02,
  });
  const options = ["말하지 않기", "건너뛰기", "잠시 쉬기"];
  options.forEach((t, i) => {
    const x = 96 + i * 530;
    rule(slide, `${row.slide_id}-opt-rule-${i}`, x, 760, 430, accent, 4);
    addText(slide, `${row.slide_id}-opt-${i}`, t, { left: x, top: 790, width: 430, height: 55 }, {
      fontSize: 29, bold: true, color: C.white,
    });
  });
}

function drawConnection(slide, row, accent) {
  slide.background.fill = C.paper;
  baseChrome(slide, row, false);
  addText(slide, `${row.slide_id}-index`, "↺", { left: 90, top: 170, width: 260, height: 200 }, {
    fontSize: 170, bold: true, color: accent,
  });
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 400, top: 255, width: 1360, height: 390 }, {
    fontSize: bodyFont(row.screen_body, 82), bold: true, color: C.navy,
  });
  addText(slide, `${row.slide_id}-cue`, "성과보다 알아차림을 돌아봅니다.", { left: 402, top: 720, width: 950, height: 55 }, {
    fontSize: 30, color: C.gray,
  });
  rule(slide, `${row.slide_id}-rule`, 402, 690, 1300, C.line, 2);
}

function drawStory(slide, row, accent) {
  slide.background.fill = C.navy;
  baseChrome(slide, row, true);
  addText(slide, `${row.slide_id}-story-label`, "STORY", { left: 88, top: 170, width: 480, height: 150 }, {
    fontSize: 112, bold: true, color: accent,
  });
  rule(slide, `${row.slide_id}-split`, 630, 188, 3, "#FFFFFF/28", 665);
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 720, top: 225, width: 1040, height: 540 }, {
    fontSize: bodyFont(row.screen_body, 64), bold: true, color: C.white, lineSpacing: 1.05,
  });
  addText(slide, `${row.slide_id}-pause`, "문장 사이에 짧은 침묵을 둡니다.", { left: 720, top: 805, width: 850, height: 45 }, {
    fontSize: 25, color: "#B8C0CC",
  });
}

function drawActivity(slide, row, accent) {
  slide.background.fill = C.navy;
  baseChrome(slide, row, true);
  addText(slide, `${row.slide_id}-activity`, "ACTIVITY", { left: 86, top: 135, width: 1560, height: 230 }, {
    fontSize: 178, bold: true, color: accent,
  });
  const text = row.screen_body;
  addText(slide, `${row.slide_id}-body`, text, { left: 94, top: 440, width: 1640, height: 340 }, {
    fontSize: bodyFont(text, 82), bold: true, color: C.white, lineSpacing: 1.0,
  });
  rule(slide, `${row.slide_id}-activity-rule`, 96, 860, 520, accent, 12);
}

function drawPrep(slide, row, accent) {
  slide.background.fill = C.warm;
  baseChrome(slide, row, false);
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 94, top: 205, width: 1650, height: 160 }, {
    fontSize: bodyFont(row.screen_body, 74), bold: true, color: C.navy,
  });
  const items = ["SKETCHBOOK", "COLOR PENCILS", "WORKBOOK"];
  const ko = ["그림의 자리", "표현의 도구", "발견의 기록"];
  items.forEach((t, i) => {
    const x = 98 + i * 570;
    circle(slide, `${row.slide_id}-prep-circle-${i}`, x, 505, 78, accent, "none", 5);
    addText(slide, `${row.slide_id}-prep-en-${i}`, t, { left: x + 110, top: 505, width: 420, height: 46 }, {
      fontSize: 29, bold: true, color: C.navy,
    });
    addText(slide, `${row.slide_id}-prep-ko-${i}`, ko[i], { left: x + 110, top: 560, width: 420, height: 42 }, {
      fontSize: 25, color: C.gray,
    });
    rule(slide, `${row.slide_id}-prep-rule-${i}`, x, 670, 485, C.line, 2);
  });
}

function drawGuide(slide, row, accent) {
  slide.background.fill = C.paper;
  baseChrome(slide, row, false);
  addText(slide, `${row.slide_id}-guide`, "DRAWING GUIDE", { left: 92, top: 168, width: 920, height: 110 }, {
    fontSize: 82, bold: true, color: accent,
  });
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 94, top: 325, width: 1630, height: 190 }, {
    fontSize: bodyFont(row.screen_body, 66), bold: true, color: C.navy,
  });
  const xs = [180, 570, 960, 1350];
  xs.forEach((x, i) => {
    circle(slide, `${row.slide_id}-guide-circle-${i}`, x, 650 + (i % 2) * 35, 72, accent, "none", 4);
    rule(slide, `${row.slide_id}-guide-line-${i}`, x + 72, 686 + (i % 2) * 35, 240, C.navy, 3);
  });
  addText(slide, `${row.slide_id}-choice`, "모두 넣을 필요는 없습니다. 선 · 색 · 거리 · 빈 공간도 표현입니다.", { left: 182, top: 820, width: 1480, height: 58 }, {
    fontSize: 28, color: C.gray,
  });
}

function drawPermission(slide, row, accent) {
  slide.background.fill = C.warm;
  baseChrome(slide, row, false);
  rule(slide, `${row.slide_id}-accent-top`, 0, 0, 1920, accent, 26);
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 155, top: 335, width: 1610, height: 280 }, {
    fontSize: bodyFont(row.screen_body, 92), bold: true, color: C.navy, alignment: "center", verticalAlignment: "middle",
  });
  addText(slide, `${row.slide_id}-small`, "YOUR PACE IS PART OF THE WORK.", { left: 510, top: 700, width: 900, height: 48 }, {
    fontSize: 28, bold: true, color: C.gray, alignment: "center",
  });
}

function drawTimer(slide, row, accent) {
  slide.background.fill = C.navy;
  baseChrome(slide, row, true);
  addText(slide, `${row.slide_id}-number`, "25", { left: 155, top: 90, width: 910, height: 670 }, {
    fontSize: 530, bold: true, color: C.white, lineSpacing: 0.8,
  });
  addText(slide, `${row.slide_id}-min`, "MIN", { left: 1130, top: 350, width: 540, height: 180 }, {
    fontSize: 145, bold: true, color: accent,
  });
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 1125, top: 590, width: 610, height: 100 }, {
    fontSize: 38, bold: true, color: C.white,
  });
  rule(slide, `${row.slide_id}-timer-rule`, 1128, 750, 570, accent, 10);
}

function drawObserve(slide, row, accent) {
  slide.background.fill = C.paper;
  baseChrome(slide, row, false);
  addText(slide, `${row.slide_id}-observe`, "LOOK AGAIN", { left: 95, top: 165, width: 1000, height: 150 }, {
    fontSize: 116, bold: true, color: `${accent}/60`,
  });
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 275, top: 385, width: 1370, height: 230 }, {
    fontSize: bodyFont(row.screen_body, 72), bold: true, color: C.navy, alignment: "center", verticalAlignment: "middle",
  });
  const frame = { l: 205, t: 330, r: 1715, b: 715 };
  rule(slide, `${row.slide_id}-tlh`, frame.l, frame.t, 115, accent, 5);
  rule(slide, `${row.slide_id}-tlv`, frame.l, frame.t, 5, accent, 115);
  rule(slide, `${row.slide_id}-trh`, frame.r - 115, frame.t, 115, accent, 5);
  rule(slide, `${row.slide_id}-trv`, frame.r, frame.t, 5, accent, 115);
  rule(slide, `${row.slide_id}-blh`, frame.l, frame.b, 115, accent, 5);
  rule(slide, `${row.slide_id}-blv`, frame.l, frame.b - 115, 5, accent, 115);
  rule(slide, `${row.slide_id}-brh`, frame.r - 115, frame.b, 115, accent, 5);
  rule(slide, `${row.slide_id}-brv`, frame.r, frame.b - 115, 5, accent, 115);
}

function drawConflict(slide, row, accent) {
  slide.background.fill = C.paper;
  baseChrome(slide, row, false);
  addText(slide, `${row.slide_id}-tension`, "TENSION / NEED", { left: 94, top: 165, width: 1180, height: 120 }, {
    fontSize: 90, bold: true, color: accent,
  });
  rule(slide, `${row.slide_id}-axis-h`, 210, 590, 1500, C.navy, 3);
  rule(slide, `${row.slide_id}-axis-v`, 960, 370, 3, C.navy, 440);
  circle(slide, `${row.slide_id}-axis-dot`, 925, 555, 72, C.navy, accent, 2);
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 210, top: 330, width: 1500, height: 220 }, {
    fontSize: bodyFont(row.screen_body, 66), bold: true, color: C.navy, alignment: "center",
  });
  addText(slide, `${row.slide_id}-axis-left`, "지켜준 것", { left: 210, top: 650, width: 650, height: 60 }, {
    fontSize: 29, bold: true, color: C.gray,
  });
  addText(slide, `${row.slide_id}-axis-right`, "지금 필요한 것", { left: 1060, top: 650, width: 650, height: 60 }, {
    fontSize: 29, bold: true, color: C.gray, alignment: "right",
  });
}

function drawShare(slide, row, accent) {
  slide.background.fill = C.navy;
  baseChrome(slide, row, true);
  addText(slide, `${row.slide_id}-share`, "SHARE / REFLECT", { left: 94, top: 155, width: 1320, height: 150 }, {
    fontSize: 108, bold: true, color: accent,
  });
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 96, top: 360, width: 1650, height: 210 }, {
    fontSize: bodyFont(row.screen_body, 70), bold: true, color: C.white,
  });
  const rules = ["설명보다 경험", "조언 없이 듣기", "“제가 들은 핵심은…”"];
  rules.forEach((t, i) => {
    const x = 100 + i * 560;
    addText(slide, `${row.slide_id}-share-n-${i}`, `0${i + 1}`, { left: x, top: 700, width: 90, height: 55 }, {
      fontSize: 30, bold: true, color: accent,
    });
    rule(slide, `${row.slide_id}-share-rule-${i}`, x, 775, 475, "#FFFFFF/35", 2);
    addText(slide, `${row.slide_id}-share-text-${i}`, t, { left: x, top: 800, width: 475, height: 62 }, {
      fontSize: 27, bold: true, color: C.white,
    });
  });
}

function drawIntegration(slide, row, accent) {
  slide.background.fill = C.warm;
  baseChrome(slide, row, false);
  circle(slide, `${row.slide_id}-big-circle`, 105, 205, 590, accent, "none", 14);
  circle(slide, `${row.slide_id}-small-circle`, 310, 410, 180, C.navy, accent, 3);
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 790, top: 290, width: 990, height: 330 }, {
    fontSize: bodyFont(row.screen_body, 76), bold: true, color: C.navy,
  });
  addText(slide, `${row.slide_id}-cue`, "말하고 싶은 만큼만, 자신의 문장으로.", { left: 795, top: 700, width: 820, height: 50 }, {
    fontSize: 29, color: C.gray,
  });
}

function drawAction(slide, row, accent) {
  slide.background.fill = C.paper;
  baseChrome(slide, row, false);
  addText(slide, `${row.slide_id}-action`, "NEXT / SMALL", { left: 94, top: 160, width: 1050, height: 140 }, {
    fontSize: 102, bold: true, color: accent,
  });
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 95, top: 360, width: 1610, height: 300 }, {
    fontSize: bodyFont(row.screen_body, 72), bold: true, color: C.navy,
  });
  rule(slide, `${row.slide_id}-action-rule`, 96, 750, 1610, C.navy, 3);
  addText(slide, `${row.slide_id}-action-cue`, "작게 시작하고 · 확인하고 · 다시 시작합니다.", { left: 96, top: 790, width: 1220, height: 60 }, {
    fontSize: 31, bold: true, color: C.gray,
  });
}

function drawClosing(slide, row, accent) {
  slide.background.fill = C.navy;
  baseChrome(slide, row, true);
  addText(slide, `${row.slide_id}-close`, "CLOSE", { left: 95, top: 140, width: 980, height: 180 }, {
    fontSize: 145, bold: true, color: `${accent}/70`,
  });
  addText(slide, `${row.slide_id}-body`, row.screen_body, { left: 150, top: 390, width: 1610, height: 250 }, {
    fontSize: bodyFont(row.screen_body, 82), bold: true, color: C.white, alignment: "center",
  });
  rule(slide, `${row.slide_id}-signature`, 350, 700, 1220, accent, 7);
  addText(slide, `${row.slide_id}-cue`, "자신의 언어로 완성합니다.", { left: 520, top: 755, width: 880, height: 60 }, {
    fontSize: 28, color: "#B8C0CC", alignment: "center",
  });
}

function renderRow(slide, row) {
  const accent = WEEK[row.week].accent;
  if (row.phase === "타이틀") return drawTitle(slide, row, accent);
  if (row.phase === "진입") return drawScene(slide, row, accent);
  if (row.phase === "체크인") return drawQuestion(slide, row, accent, false);
  if (row.phase === "안전") return drawSafety(slide, row, accent);
  if (row.phase === "연결") return drawConnection(slide, row, accent);
  if (row.phase === "스토리") return drawStory(slide, row, accent);
  if (row.phase === "공개") return drawActivity(slide, row, accent);
  if (row.phase === "준비") return drawPrep(slide, row, accent);
  if (row.phase === "안내") return drawGuide(slide, row, accent);
  if (row.phase === "허용") return drawPermission(slide, row, accent);
  if (row.phase === "작업") return drawTimer(slide, row, accent);
  if (row.phase === "관찰" && row.slide_no === "12") return drawObserve(slide, row, accent);
  if (row.phase === "관찰") return drawQuestion(slide, row, accent, false);
  if (row.phase === "발화") return drawQuestion(slide, row, accent, true);
  if (row.phase === "심화") return drawConflict(slide, row, accent);
  if (row.phase === "나눔") return drawShare(slide, row, accent);
  if (row.phase === "통합") return drawIntegration(slide, row, accent);
  if (row.phase === "적용") return drawAction(slide, row, accent);
  if (row.phase === "종결") return drawClosing(slide, row, accent);
  return drawScene(slide, row, accent);
}

function createDeck(rows, weekMeta) {
  const deck = Presentation.create({ slideSize: { width: 1920, height: 1080 } });
  rows.forEach((row, index) => {
    const slide = deck.slides.add();
    renderRow(slide, row);
    slide.speakerNotes.textFrame.setText(
      buildNotes(row, rows[index + 1], weekMeta[row.week]),
    );
    slide.speakerNotes.setVisible(true);
  });
  return deck;
}

async function writeBlob(file, blob) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, new Uint8Array(await blob.arrayBuffer()));
}

async function exportPptx(deck, file) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const pptx = await PresentationFile.exportPptx(deck);
  await pptx.save(file);
}

async function renderDeck(deck, dir) {
  await fs.mkdir(dir, { recursive: true });
  let index = 0;
  for (const slide of deck.slides.items) {
    index += 1;
    const png = await deck.export({ slide, format: "png", scale: 1 });
    await writeBlob(path.join(dir, `slide-${String(index).padStart(3, "0")}.png`), png);
    const layout = await slide.export({ format: "layout" });
    await fs.writeFile(
      path.join(dir, `slide-${String(index).padStart(3, "0")}.layout.json`),
      await layout.text(),
    );
    if (index % 10 === 0) console.log(`Rendered ${index}/${deck.slides.items.length}`);
  }
  const montage = await deck.export({ format: "webp", montage: true, scale: 0.35 });
  await writeBlob(path.join(dir, "MASTER_montage.webp"), montage);
}

async function loadData() {
  const csv = await fs.readFile(MANIFEST, "utf8");
  const rows = parseCsv(csv);
  const weekMeta = {};
  const scripts = await fs.readdir(path.join(SOURCE, "02_WEEKLY_SCRIPT"));
  for (const file of scripts) {
    const match = file.match(/^(W\d{2})_/);
    if (!match) continue;
    const text = await fs.readFile(path.join(SOURCE, "02_WEEKLY_SCRIPT", file), "utf8");
    weekMeta[match[1]] = readWeekMeta(text);
  }
  return { rows, weekMeta };
}

async function makePrototype(rows, weekMeta) {
  const picks = ["W01-S01", "W01-S09", "W01-S13"].map((id) =>
    rows.find((r) => r.slide_id === id),
  );
  const deck = createDeck(picks, weekMeta);
  const protoDir = path.join(TMP, "prototype");
  await fs.rm(protoDir, { recursive: true, force: true });
  await renderDeck(deck, protoDir);
  await exportPptx(deck, path.join(protoDir, "대표시안_3장.pptx"));
}

async function makeFull(rows, weekMeta) {
  await fs.mkdir(path.join(OUT, "01_MASTER"), { recursive: true });
  await fs.mkdir(path.join(OUT, "02_WEEKLY_PPT"), { recursive: true });
  await fs.mkdir(path.join(OUT, "03_REVIEW"), { recursive: true });
  await fs.mkdir(path.join(OUT, "04_SOURCE", "사용한_이미지"), { recursive: true });
  await fs.mkdir(path.join(OUT, "04_SOURCE", "제작_메타데이터"), { recursive: true });

  const master = createDeck(rows, weekMeta);
  const masterFile = path.join(
    OUT,
    "01_MASTER",
    "DAILYCOACHING_미술심리코칭_6주_진행슬라이드_MASTER_v1.0.pptx",
  );
  await exportPptx(master, masterFile);
  console.log(`Exported MASTER: ${masterFile}`);

  for (const week of Object.keys(WEEK_FILES)) {
    const subset = rows.filter((r) => r.week === week);
    const deck = createDeck(subset, weekMeta);
    const file = path.join(OUT, "02_WEEKLY_PPT", WEEK_FILES[week]);
    await exportPptx(deck, file);
    console.log(`Exported ${week}: ${file}`);
  }

  const scriptText = rows
    .map((row, index) => {
      const header = [
        "=".repeat(84),
        `${row.slide_id}  |  ${row.screen_title}  |  ${row.time_min}분`,
        `참여자 화면: ${row.screen_body}`,
        "-".repeat(84),
      ].join("\n");
      return `${header}\n${buildNotes(row, rows[index + 1], weekMeta[row.week])}`;
    })
    .join("\n\n");
  await fs.writeFile(path.join(OUT, "03_REVIEW", "강사대본_전체.txt"), scriptText, "utf8");

  const metadata = {
    project: "DAILYCOACHING 성인 미술심리코칭 6주 강사용 진행 슬라이드",
    version: "1.0",
    generated_at: new Date().toISOString(),
    slide_count: rows.length,
    week_counts: Object.fromEntries(
      Object.keys(WEEK).map((w) => [w, rows.filter((r) => r.week === w).length]),
    ),
    week_minutes: Object.fromEntries(
      Object.keys(WEEK).map((w) => [
        w,
        rows.filter((r) => r.week === w).reduce((a, r) => a + Number(r.time_min), 0),
      ]),
    ),
    source_manifest: "03_DATA/SLIDE_MANIFEST_114.csv",
    design: {
      size: "1920x1080",
      ratio: "16:9",
      font: "Noto Sans KR (빌드 대체) / Pretendard 권장",
      colors: C,
    },
  };
  await fs.writeFile(
    path.join(OUT, "04_SOURCE", "제작_메타데이터", "production_metadata.json"),
    JSON.stringify(metadata, null, 2),
    "utf8",
  );
  await fs.copyFile(
    new URL(import.meta.url),
    path.join(OUT, "04_SOURCE", "제작_메타데이터", "build_presentation.mjs"),
  );

  const renderDir = path.join(TMP, "master_render");
  await fs.rm(renderDir, { recursive: true, force: true });
  await renderDeck(master, renderDir);
}

async function main() {
  const { rows, weekMeta } = await loadData();
  if (rows.length !== 114) throw new Error(`Expected 114 rows, found ${rows.length}`);
  const mode = process.argv[2] ?? "full";
  if (mode === "prototype") await makePrototype(rows, weekMeta);
  else await makeFull(rows, weekMeta);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
